<footer class="main-footer">
  <div class="float-right d-none d-sm-block">Todos los derechos reservado</div>
  <strong>Elaborado para el curso de Gestion de Mantenimiento - 2022</strong>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->